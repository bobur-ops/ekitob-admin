import WithSideBar from "../../layouts/WithSideBar";

const Users = () => {
  return <WithSideBar>Users</WithSideBar>;
};

export default Users;
